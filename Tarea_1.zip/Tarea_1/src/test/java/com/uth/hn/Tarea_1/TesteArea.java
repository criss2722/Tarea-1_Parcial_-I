package com.uth.hn.Tarea_1;


import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class TesteArea {
    @Test
    public void testCalcularAreaCirculo() {
        double radio = 5.0;
        double resultadoEsperado = 78.54;
        double resultadoReal = Calculos.AreaCirculo(radio);
        assertEquals(resultadoEsperado, resultadoReal, 0.01);
    }
    @Test
    public void testCalcularAreaCuadrado() {
        double lado = 4.0;
        double resultadoEsperado = 16.0;
        double resultadoReal = Calculos.AreaCuadrado(lado);
        assertEquals(resultadoEsperado, resultadoReal, 0.01);
    }

    @Test
    public void testCalcularAreaRectangulo() {
        double base = 6.0;
        double altura = 3.0;
        double resultadoEsperado = 18.0;
        double resultadoReal = Calculos.AreaRectangulo(base, altura);
        assertEquals(resultadoEsperado, resultadoReal, 0.01);
    }

    @Test
    public void testCalcularAreaTriangulo() {
        double base = 8.0;
        double altura = 5.0;
        double resultadoEsperado = 20.0;
        double resultadoReal = Calculos.AreaTriangulo(base, altura);
        assertEquals(resultadoEsperado, resultadoReal, 0.01);
    }
}

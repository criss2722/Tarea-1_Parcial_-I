package com.uth.hn.Tarea_1;

public class Calculos {
	
	    public static double AreaCirculo(double radio) {
	        return Math.PI * radio * radio;
	    }

	    public static double AreaCuadrado(double lado) {
	        return lado * lado;
	    }

	    public static double AreaRectangulo(double base, double altura) {
	        return base * altura;
	    }

	    public static double AreaTriangulo(double base, double altura) {
	        return 0.5 * base * altura;
	    }
	}

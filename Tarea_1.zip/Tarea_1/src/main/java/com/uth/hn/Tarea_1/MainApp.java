package com.uth.hn.Tarea_1;

import java.util.Scanner;

public class MainApp 
{
    public static void main( String[] args ) {
    Scanner scanner = new Scanner(System.in);

    while (true) {
        System.out.println("Selecciona una operación:");
        System.out.println("1. Calcular el área de un círculo");
        System.out.println("2. Calcular el área de un cuadrado");
        System.out.println("3. Calcular el área de un rectángulo");
        System.out.println("4. Calcular el área de un triángulo");
        System.out.println("0. Salir");

        int opcion = scanner.nextInt();

        if (opcion == 0) {
            break;
        }

        double area = 0.0;

        switch (opcion) {
            case 1:
                System.out.print("Ingresa el radio del círculo: ");
                double radio = scanner.nextDouble();
                area = Calculos.AreaCirculo(radio);
                break;
            case 2:
                System.out.print("Ingresa el lado del cuadrado: ");
                double lado = scanner.nextDouble();
                area = Calculos.AreaCuadrado(lado);
                break;
            case 3:
                System.out.print("Ingresa la base del rectángulo: ");
                double base = scanner.nextDouble();
                System.out.print("Ingresa la altura del rectángulo: ");
                double altura = scanner.nextDouble();
                area = Calculos.AreaRectangulo(base, altura);
                break;
            case 4:
                System.out.print("Ingresa la base del triángulo: ");
                base = scanner.nextDouble();
                System.out.print("Ingresa la altura del triángulo: ");
                altura = scanner.nextDouble();
                area = Calculos.AreaTriangulo(base, altura);               	
                break;
            default:
                System.out.println("Opción no válida");
                continue;
        }

        System.out.println("El área es: " + area);
    }

    scanner.close();
}
}
